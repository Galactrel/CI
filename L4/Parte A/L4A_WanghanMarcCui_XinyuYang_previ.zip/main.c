/* Main.c 
 * Processor: PIC18F45K22
 * Compiler:  MPLAB XC8
 */

#include <xc.h>
#include <string.h>
#include <stdio.h>
#include "config.h"
#include "GLCD.h"
#define _XTAL_FREQ 8000000  


// Variables Globals
const char * intro[4] = {"L4A GLCD\n",
			"--------\n",
			"Wanghan Marc Cui",
			"Xinyu Yang"};


void configPIC(){ 
   ANSELA=0x00;
   ANSELAbits.ANSA2 = 1;
   ANSELB=0x00;                  
   ANSELC=0x00;                  
   ANSELD=0x00;                  
   
   TRISA=0x00;
   TRISAbits.TRISA2 = 1;
   TRISD=0x00;
   TRISB=0x00;
    
   PORTD=0x00;
   PORTB=0x00;  
   
   // Config ADC en portA3:
   ADCON0bits.CHS = 2; // Select A3
   
   ADCON1bits.PVCFG = 0; //Vref+ = Vdd
   ADCON1bits.NVCFG = 0; //Vref- = 0V
   
   ADCON2bits.ADCS = 0b001; //Tad = 1 us
   ADCON2bits.ACQT = 0b100; // Tacq = 8us
   ADCON2bits.ADFM = 1; //Right justified
   
   ADCON0bits.ADON = 1; // ADC ON
}


void writeTxt(byte page, byte y, char * s) {
   int i=0;
   while (*s!='\n' && *s!='\0') 
   {
      putchGLCD(page, y+i, *(s++));
      i++;
   };
}

// Imprimeix el string s, en la pagina page, al centre de la GLCD 
void writeCentredTxt(byte page, char * s) {
   int y = 13 - strlen(s)/2;
   writeTxt(page, y, s);
}

// Imprimeix una barra en la pagina p [0:7], des de la posició yi [0:127] fins a la posició yf [0:127]
void ProgressBar(int p, int yi, int yf) {
   for (int i = yi; i < yf; i++) {
      writeByte(p, i, 0xFF);
   }
}


void main(void)
{
   configPIC();
   
   GLCDinit();		   //Inicialitzem la pantalla
   clearGLCD(0,7,0,127);   //Esborrem pantalla
   setStartLine(0);        //Definim linia d'inici

   // Mostrem textos de introducción
   for (int p = 2; p < 6; p++) {
      writeCentredTxt(p, intro[p-2]);
   }

   __delay_ms(1000);
   
   clearGLCD(0, 7, 0, 127);
   
   // Mostramos los textos informativos de la ADC
   const char * text[5] = {"Info ADC\n",
			   "--------\n",
			   "Valor llegit bits:\n",
			   "Valor llegit volt:\n",
			   "Percentatge llegit:\n"
			  };
   
   for (int i = 0; i < 2; i++) {
      writeCentredTxt(i, text[i]);
   }
   
   for (int i = 2; i < 5; i++) {
      writeTxt(i, 1, text[i]);
   }
   
   int old_res = 0;
   
   while (1)
   {   
      GODONE = 1;
      while (GODONE);
      
      int res = (ADRESH << 8) + ADRESL; //num binario de la escala leida
      
      // Calculem el voltatge
      int e_volt = res*5/1023; 			// Part entera
      int d_volt = ((res*5) % 1023)*10/1023;	// Part decimal
      
      
      // Codi antic: (No sabem si funciona amb el float:
      /*
      float volt = res*5.0/1023;
      int e_volt = (int) volt;
      int d_volt = volt*10 - e_volt*10;
      */
      
      int percent = res*25/255;
      
      // Mostrem els bits
      writeNum(2, 20, res);
      
      // Mostrem els volts
      writeNum(3, 20, e_volt);
      putchGLCD(3, 21, '.');
      writeNum(3, 22, d_volt);
      
      // Mostrem el percentatge
      writeNum(4, 20, percent);
      putchGLCD(4, 23, '%');
      
      // Mostrem la barra de progrés
      ProgressBar(7, 0, (res*32/255));
      
      // Comprovem quan s'actualitza per netegar els valors antics
      if (old_res != res) { 
	 clearGLCD(2, 4, 100, 127);
	 clearGLCD(7, 7, 0, 127);
      }
      old_res = res;
   }
}
